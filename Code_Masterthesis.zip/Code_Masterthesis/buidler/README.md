# Benötigte Pakete herunterladen

# 'npm install'

# Test ausführen

# 'npx buidler test'
